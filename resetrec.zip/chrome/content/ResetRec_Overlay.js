function ResetRec_reset_rec ()
{
  // just define no recipent and call CompFields2Recipients

  gMsgCompose.compFields.to = "";
  gMsgCompose.compFields.cc = "";
  gMsgCompose.compFields.bcc = "";
  // release 1.2: add other fields
  gMsgCompose.compFields.replyTo = "" ;
  gMsgCompose.compFields.newsgroups = "" ;
  gMsgCompose.compFields.followupTo = "" ;

  CompFields2Recipients(gMsgCompose.compFields) ;

  // gives focus to the address field
  awSetFocus (1, awGetInputElement(1)) ;
}

function ResetRec_init (event)
{

    // if first time after installation, force button display
    this.prefs = Components.classes["@mozilla.org/preferences-service;1"]
      .getService(Components.interfaces.nsIPrefService)
      .getBranch("extensions.ResetRec.");
    this.prefs.QueryInterface(Components.interfaces.nsIPrefBranch2);

    if (!this.prefs.prefHasUserValue("firstrun")) {

      let reset_rec_toolbarElement = document.getElementById("composeToolbar");
      if (reset_rec_toolbarElement==null) {
        reset_rec_toolbarElement = document.getElementById("composeToolbar2");
      }
      if (reset_rec_toolbarElement!=null) {
        reset_rec_toolbarElement.insertItem("ResetRec-button", null,null,false);
        reset_rec_toolbarElement.setAttribute("currentset", reset_rec_toolbarElement.currentSet);
        document.persist(reset_rec_toolbarElement.id,"currentset");
      }
      this.prefs.setBoolPref("firstrun",true); 
    }
}

window.addEventListener("load", ResetRec_init, false);

