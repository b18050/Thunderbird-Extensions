pref("extensions.ResetRec@lejav.com.description", "chrome://resetrec/locale/ResetRec.properties"); 
