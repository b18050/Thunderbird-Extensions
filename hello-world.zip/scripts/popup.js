/*
// Derived from https://developer.thunderbird.net/add-ons/about-add-ons/hello-world
// Modified by: Chandan Prakash on 18-04-2020
// Added modifier's name
*/

console.log('Hello, World! - from popup.js');
console.log(' Author - Chandan Prakash')